![Screenshot 2024-03-04 002626](https://github.com/AdityaPatil100/Power-Bi-projects/assets/86911300/3860ee67-5c34-4520-92dd-901c34b3cacb)
